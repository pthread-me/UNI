echo "full path: $PWD"
echo "user: $USER"
echo "system: $(uname)"
echo "kernel: $(uname -v)"
